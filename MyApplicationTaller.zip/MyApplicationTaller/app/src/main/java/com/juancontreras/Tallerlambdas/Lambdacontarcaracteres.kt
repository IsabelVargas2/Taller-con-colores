package com.juancontreras.Tallerlambdas

fun main(){
    fun contarCaracteres(texto: String, criterio: (Char) -> Boolean): Int {
        return texto.count(criterio)
    }

// Uso
    val totalLetras = contarCaracteres("Hola mundo, soy juan") { it.isLetter() }
    val totalVocales = contarCaracteres("Hola mundo, soy juan ") { it in "aeiouAEIOU" }
    val totalConsonantes = contarCaracteres("Hola mundo, soy juan") { it.isLetter() && it !in "aeiouAEIOU" }

    println("Total de letras: $totalLetras")       // Output: 9
    println("Total de vocales: $totalVocales")     // Output: 4
    println("Total de consonantes: $totalConsonantes") // Output: 5

}