package com.juancontreras.Tallerlambdas

fun main(){
    val concatenar: (String, String) -> String = { primera, segunda -> "$primera $segunda" }

    println(concatenar("Hola", "Mundo")) // Output: "Hola Mundo"

}