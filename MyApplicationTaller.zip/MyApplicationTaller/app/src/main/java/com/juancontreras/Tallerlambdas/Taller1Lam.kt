package com.juancontreras.Tallerlambdas

fun main(){
    val saludar: (String) ->String = {
        nombre -> "Hola, $nombre" }
    println(saludar("Juan"))
}




