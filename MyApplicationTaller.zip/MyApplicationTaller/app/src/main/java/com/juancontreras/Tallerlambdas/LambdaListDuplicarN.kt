package com.juancontreras.Tallerlambdas

fun main(){
    val duplicarValor: (List<Int>) -> List<Int> = { lista ->
        lista.map { it * 2 }  // Multiplicamos cada número por 2
    }

    val numeros = listOf(1, 2, 3, 4, 5)
    val resultado = duplicarValor(numeros)

    println("Lista con los valores duplicados: $resultado")
}