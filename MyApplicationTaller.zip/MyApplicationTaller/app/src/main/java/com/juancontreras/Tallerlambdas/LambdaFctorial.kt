package com.juancontreras.Tallerlambdas

fun main(){
    val factorial: (Int) -> Int = { n ->
        if (n == 0) 1 else (1..n).reduce { acc, num -> acc * num }
    }

    println(factorial(5)) // Output: 120
}