package com.juancontreras.Tallerlambdas

fun main(){
    val filtrarPares: (List<Int>) -> List<Int> = { numeros -> numeros.filter { it % 2 == 0 } }

    val lista = listOf(1, 2, 3, 4, 5, 6, 7, 8, 9, 10)

    println(filtrarPares(lista)) // Output: [2, 4, 6]

}