package com.juancontreras.Tallerlambdas

fun main(){
    val invertirCadena: (String) -> String = { cadena -> cadena.reversed() }

    println(invertirCadena("Kotlin")) // Output: "niltok"

}