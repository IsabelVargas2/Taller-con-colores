package com.juancontreras.Tallerlambdas

fun main(){
    val estaVacia: (List<Any>) -> Boolean = { lista -> lista.isEmpty() }

    println(estaVacia(listOf(1,2,3,4))) // Output: false
    println(estaVacia(listOf()))       // Output: true

}