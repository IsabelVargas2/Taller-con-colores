package com.juancontreras.Tallerlambdas

fun main(){
    fun transformarNombres(nombres: List<String>, transformacion: (String) -> String): List<String> {
        return nombres.map(transformacion)
    }

// Uso
    val nombres = listOf("Juan", "Carlos", "Lucía")

    val nombresEnMayusculas = transformarNombres(nombres) { it.uppercase() }
    val nombresConPrefijo = transformarNombres(nombres) { "Usuario: $it" }

    println(nombresEnMayusculas) // Output: ["ANA", "CARLOS", "LUCÍA"]
    println(nombresConPrefijo)   // Output: ["Usuario: Ana", "Usuario: Carlos", "Usuario: Lucía"]

}