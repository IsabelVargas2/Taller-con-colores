package com.juancontreras.Tallerlambdas

fun main(){
    val contieneSubcadena: (String, String) -> Boolean = { texto, subcadena -> texto.contains(subcadena) }

    println(contieneSubcadena("Kotlin es genial", "es"))  // Output: true
    println(contieneSubcadena("Hola Mundo", "Kotlin"))    // Output: false

}