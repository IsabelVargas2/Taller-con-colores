package com.juancontreras.Tallerlambdas

fun main(){
    fun esBotonHabilitado(texto: String, validacion: (String) -> Boolean): Boolean {
        return validacion(texto)
    }


    val habilitado = esBotonHabilitado("Hola") { it.isNotBlank() }

    println("¿Botón habilitado?: $habilitado") // Output: true

    val deshabilitado = esBotonHabilitado("") { it.isNotBlank() }

    println("¿Botón habilitado?: $deshabilitado") // Output: false

}