package com.juancontreras.Tallerlambdas

fun main(){
    val esPositivo : (Int) -> Boolean = {numero -> numero > 0}

    println(esPositivo(5))
    println(esPositivo(-3))
}