package com.juancontreras.Tallerlambdas

fun main(){
    val encontrarMaximo: (List<Int>) -> Int = { numeros -> numeros.maxOrNull() ?: throw NoSuchElementException("La lista está vacía") }

    val lista = listOf(10, 20, 55, 30)

    println(encontrarMaximo(lista)) // Output: 30

}